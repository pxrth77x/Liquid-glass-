package dev.glass;

import android.app.Dialog;
import android.graphics.drawable.*;
import android.view.*;
import java.util.*;
import java.util.regex.Pattern;
import de.robv.android.xposed.*;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class Hook implements IXposedHookLoadPackage {
    /** true = log each kind of SystemUI view, to find the right names on your build. */
    private static final boolean DUMP = true;
    /** Matched against "ClassName#resource_id". Tune using the dump. */
    private static final Pattern TARGET = Pattern.compile(
        "(QSTileView|QSTileViewImpl|NTQSTile\\w*|#qs_tile\\w*|#qs_brightness\\w*|#brightness_slider"
        + "|#volume_dialog\\w*background|#qs_media\\w*|#backgroundNormal)");
    private final Set<String> seen = new HashSet<>();

    @Override public void handleLoadPackage(LoadPackageParam lp) {
        hookDialogs();
        if (!lp.packageName.equals("com.android.systemui")) return;
        XposedHelpers.findAndHookMethod(View.class, "onAttachedToWindow", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                View v = (View) p.thisObject;
                String key = describe(v);
                if (DUMP && seen.add(key)) XposedBridge.log("LG view " + key);
                if (TARGET.matcher(key).find()) v.post(() -> apply(v));
            }
        });
    }

    private static String describe(View v) {
        String id = "";
        try { if (v.getId() != View.NO_ID) id = v.getResources().getResourceEntryName(v.getId()); }
        catch (Exception ignored) { }
        return v.getClass().getSimpleName() + "#" + id;
    }

    private static void apply(View v) {
        try {
            if (!v.isAttachedToWindow()) return;
            float dp = v.getResources().getDisplayMetrics().density;
            float radius = 28 * dp;
            Drawable bg = new Glass(radius, dp);
            try { // live cross-window blur (hidden API)
                Object root = XposedHelpers.callMethod(v, "getViewRootImpl");
                Drawable blur = (Drawable) XposedHelpers.callMethod(root, "createBackgroundBlurDrawable");
                XposedHelpers.callMethod(blur, "setBlurRadius", (int) (18 * dp));
                XposedHelpers.callMethod(blur, "setCornerRadius", radius);
                XposedHelpers.callMethod(blur, "setColor", 0x22FFFFFF);
                bg = new LayerDrawable(new Drawable[]{blur, bg});
            } catch (Throwable t) { XposedBridge.log("LG blur unavailable: " + t); }
            v.setBackground(bg);
            // The foreground gloss stays even if SystemUI repaints the background.
            v.setForeground(new Glass(radius, dp));
        } catch (Throwable t) { XposedBridge.log(t); }
    }

    private static void hookDialogs() {
        XposedHelpers.findAndHookMethod(Dialog.class, "onStart", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                try {
                    Window w = ((Dialog) p.thisObject).getWindow();
                    if (w == null || !w.isFloating()) return;
                    float dp = w.getContext().getResources().getDisplayMetrics().density;
                    GradientDrawable tint = new GradientDrawable();
                    tint.setColor(0x66202020);
                    tint.setCornerRadius(28 * dp);
                    w.setBackgroundDrawable(new InsetDrawable(
                        new LayerDrawable(new Drawable[]{tint, new Glass(28 * dp, dp)}), (int) (16 * dp)));
                    w.setBackgroundBlurRadius((int) (24 * dp));
                } catch (Throwable t) { XposedBridge.log(t); }
            }
        });
    }
}
