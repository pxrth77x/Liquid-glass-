package dev.glass;

import android.graphics.*;
import android.graphics.drawable.Drawable;

/** Specular rim, edge glow and soft sheen, drawn with AGSL. */
final class Glass extends Drawable {
    private static final String AGSL =
        "uniform float2 size; uniform float radius; uniform float dp;\n" +
        "half4 main(float2 p) {\n" +
        "  float2 c = size * 0.5;\n" +
        "  float2 q = abs(p - c) - c + radius;\n" +
        "  float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - radius;\n" +
        "  float mask = 1.0 - smoothstep(-1.0, 0.5, d);\n" +
        "  float2 m = max(q + radius, 0.001);\n" +
        "  float2 n = normalize(sign(p - c) * m * m + 0.0001);\n" +
        "  float light = pow(abs(dot(n, normalize(float2(-0.6, -0.8)))), 4.0);\n" +
        "  float line = exp(d / (1.2 * dp));\n" +
        "  float glow = exp(d / (9.0 * dp));\n" +
        "  float sheen = 0.08 * (1.0 - smoothstep(0.0, 0.6, p.y / size.y));\n" +
        "  float a = clamp(0.04 + sheen + line * (0.15 + 0.65 * light) + glow * 0.12 * light, 0.0, 1.0) * mask;\n" +
        "  return half4(a, a, a, a);\n" +
        "}";
    private final RuntimeShader shader = new RuntimeShader(AGSL);
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float radius, dp;

    Glass(float radius, float dp) { this.radius = radius; this.dp = dp; paint.setShader(shader); }

    @Override public void draw(Canvas canvas) {
        Rect b = getBounds();
        if (b.isEmpty() || !canvas.isHardwareAccelerated()) return;
        shader.setFloatUniform("size", b.width(), b.height());
        shader.setFloatUniform("radius", Math.min(radius, Math.min(b.width(), b.height()) / 2f));
        shader.setFloatUniform("dp", dp);
        canvas.save();
        canvas.translate(b.left, b.top);
        canvas.drawRect(0, 0, b.width(), b.height(), paint);
        canvas.restore();
    }
    @Override public void setAlpha(int a) { paint.setAlpha(a); }
    @Override public void setColorFilter(ColorFilter f) { paint.setColorFilter(f); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
